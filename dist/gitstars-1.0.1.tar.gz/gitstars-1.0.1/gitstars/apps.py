from django.apps import AppConfig


class GitstarsConfig(AppConfig):
    name = 'gitstars'
